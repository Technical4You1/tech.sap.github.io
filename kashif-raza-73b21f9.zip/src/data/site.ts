// Everything the site says about Kashif lives here, so a page never invents a
// figure and the same project reads the same way in three places.

export const person = {
  name: 'Kashif Raza',
  role: 'SAP Basis Consultant',
  focus: 'SAP HANA · S/4HANA',
  summary:
    'SAP Basis consultant with three years running SAP system administration, HANA database management, monitoring, upgrades and troubleshooting across S/4HANA, ECC and Linux landscapes.',
  email: 'kashifmpu@gmail.com',
  phone: '+91 62050 87590',
  phoneHref: '+916205087590',
  whatsapp: 'https://wa.me/916205087590',
  linkedin: 'https://linkedin.com/in/technical4you',
  location: 'Bokaro, Jharkhand, India',
  currentLocation: 'Delhi NCR, India',
  resume: '/resume.pdf',
} as const

export const facts = [
  { label: 'Role', value: 'SAP Basis Consultant' },
  { label: 'Experience', value: '3 years in SAP Basis' },
  { label: 'Based in', value: 'India' },
] as const

export const skills = [
  'SAP Basis',
  'SAP HANA Database',
  'S/4HANA Upgrade',
  'Linux Server',
  'Windows Server',
  'AWS Cloud',
  'Azure Cloud',
  'Networking',
] as const

export type Project = {
  slug: string
  title: string
  client: string
  scope: string
  // A version path is drawn only where both ends of it are known.
  path?: string[]
  landscape: string
  summary: string
  detail: string
}

export const projects: Project[] = [
  {
    slug: 'nepal-conglomerate',
    title: 'S/4HANA upgrade',
    client: "One of Nepal's largest private-sector business groups",
    scope: 'Upgrade',
    path: ['S/4HANA 2022', 'S/4HANA'],
    landscape: 'PRD · HANA · Linux',
    summary: 'Delivered an SAP S/4HANA upgrade from 2022 to the next release.',
    detail:
      'Ran the upgrade from S/4HANA 2022 on a live HANA landscape for a diversified business group — the technical preparation, the SUM run and the post-upgrade checks that bring the system back to business.',
  },
  {
    slug: 'force-motors',
    title: 'S/4HANA upgrade',
    client: 'Force Motors Limited, automotive manufacturing',
    scope: 'Upgrade',
    path: ['S/4HANA 1709', 'S/4HANA 2025 Cloud Private Edition'],
    landscape: 'PRD · HANA · Cloud Private Edition',
    summary: 'Upgraded 1709 to 2025 Cloud Private Edition with a senior consultant.',
    detail:
      'Upgraded SAP S/4HANA 1709 to SAP S/4HANA 2025 Cloud Private Edition in collaboration with a senior consultant. The jump spans several release years, so the preparation — modification adjustment, SPDD/SPAU and the downtime plan — carried most of the risk.',
  },
  {
    slug: 'dr-build',
    title: 'Disaster recovery build',
    client: 'Manufacturing client',
    scope: 'Build',
    landscape: 'DR site · HANA replication · S/4HANA 2022',
    summary: 'Stood up S/4HANA 2022 on the DR site off the replicated HANA database.',
    detail:
      'Built the SAP S/4HANA 2022 application tier on the disaster-recovery site against the existing replicated HANA database, so the landscape has a warm standby rather than a database with no application server behind it.',
  },
]

export type Runbook = {
  slug: string
  title: string
  tier: 'free' | 'premium' | 'soon'
  step?: number
  summary: string
  href?: string
  pages?: number
  covers?: string
}

export const runbooks: Runbook[] = [
  {
    slug: 'hana-installation',
    title: 'HANA database installation',
    tier: 'free',
    step: 1,
    summary:
      'Installing SAP HANA with the lifecycle management tool on a supported Linux host — prerequisites through to a running database.',
    href: '/docs/HANA%20DB%20Installation.pdf#toolbar=0&navpanes=0',
  },
  {
    slug: 'application-server',
    title: 'Application server installation and setup',
    tier: 'free',
    step: 2,
    summary:
      'Building the SAP application server on a supported Windows host with the lifecycle management tool, step by step.',
    href: '/docs/Installation%20and%20Setup%20Application%20Server1.pdf#toolbar=0&navpanes=0',
  },
  {
    slug: 'sop-3',
    title: 'New SOP in preparation',
    tier: 'soon',
    summary: 'Being written. It will appear in this list, free, when it is ready.',
  },
  {
    slug: 'sop-4',
    title: 'New SOP in preparation',
    tier: 'soon',
    summary: 'Being written. It will appear in this list, free, when it is ready.',
  },
  {
    slug: 'sop-5',
    title: 'New SOP in preparation',
    tier: 'soon',
    summary: 'Being written. It will appear in this list, free, when it is ready.',
  },
  {
    slug: 'sop-6',
    title: 'New SOP in preparation',
    tier: 'soon',
    summary: 'Being written. It will appear in this list, free, when it is ready.',
  },
]

export const premium: Array<{
  slug: string
  title: string
  pages: number
  covers: string
}> = [
  {
    slug: 's4hana-upgrade',
    title: 'S/4HANA upgrade runbook',
    pages: 43,
    covers:
      'The complete S/4HANA 2025 upgrade procedure with Software Update Manager, from a Basis administrator’s side of the work: preparation, SUM phases, downtime and the checks after the system comes up.',
  },
  {
    slug: 'daily-health-check',
    title: 'SAP Basis daily health check pack',
    pages: 12,
    covers:
      'Daily checklists and monitoring SOPs for verifying availability, performance, data integrity and security across an SAP landscape before business hours begin.',
  },
  {
    slug: 'azure-vm',
    title: 'Virtual machine on Microsoft Azure',
    pages: 10,
    covers:
      'Creating an Azure virtual machine sized for practising SAP HANA database and application server installations, so a full practice landscape needs no physical server.',
  },
]

// Each request names its own runbook in the subject line, so the reply is
// never ambiguous. Replace this with a confirmed address if it changes.
const REQUEST_INBOX = 'kashifmpu@gmail.com'

export function requestHref(title: string) {
  return `mailto:${REQUEST_INBOX}?subject=${encodeURIComponent(`Request for ${title}`)}`
}

export const roles = [
  {
    title: 'SAP Basis Consultant',
    company: 'Excelligent Consulting Services',
    from: 'Dec 2025',
    to: 'Present',
    current: true,
    points: [
      'Managing end-to-end SAP system administration across ECC and S/4HANA landscapes.',
      'Troubleshooting technical issues alongside functional, ABAP and infrastructure teams.',
      'Monitoring system health, background jobs, work processes and HANA database performance.',
      'Involved in SAP S/4HANA 2025 on-premise upgrade activities using SUM.',
    ],
  },
  {
    title: 'Associate SAP Basis',
    company: 'Progression Infonet',
    from: 'Nov 2023',
    to: 'Dec 2025',
    current: false,
    points: [
      'Managed the technical aspects of SAP systems, keeping them running and performant.',
      'Handled system analysis, monitoring, upgrades and authorization management.',
      'Managed user administration and the day-to-day SAP administration tasks.',
    ],
  },
] as const
