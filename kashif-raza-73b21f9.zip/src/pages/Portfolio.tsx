import { Link } from 'react-router'
import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { projects } from '@/data/site'

/* A version path is drawn as a sequence only where both ends are known.
   Where one is a placeholder in the source, the landscape and scope carry it. */
function VersionPath({ path }: { path: string[] }) {
  return (
    <ol className="flex flex-wrap items-center gap-x-3 gap-y-2" aria-label="Version path">
      {path.map((v, i) => (
        <li key={v} className="flex items-center gap-3">
          {i > 0 && (
            <ArrowRight aria-hidden="true" className="size-4 text-primary" strokeWidth={1.5} />
          )}
          <span
            className={
              i === path.length - 1
                ? 'rounded-sm border border-primary/40 bg-primary-soft px-2 py-1 font-label text-xs text-primary'
                : 'rounded-sm border border-border bg-background px-2 py-1 font-label text-xs text-foreground/80'
            }
          >
            {v}
          </span>
        </li>
      ))}
    </ol>
  )
}

export default function Portfolio() {
  return (
    <main>
      <section className="bg-background">
        <div className="mx-auto max-w-content px-gutter pt-12 pb-10 md:pt-16">
          <h1 className="font-display text-[length:var(--hero-mobile)] font-semibold tracking-[-0.025em] sm:text-[length:var(--hero-size)] sm:leading-[1.04]">
            Portfolio
          </h1>
          <p className="mt-4 max-w-2xl text-[0.975rem] leading-7 text-muted-foreground">
            Three landscape projects — two S/4HANA upgrades and a disaster-recovery build. Client
            names appear where they are public; the rest are described by sector.
          </p>
        </div>
      </section>

      <section className="bg-card">
        <div className="mx-auto max-w-content space-y-4 px-gutter py-section">
          {projects.map((p, i) => (
            <article
              key={p.slug}
              className="grid gap-6 rounded-lg bg-background p-5 sm:p-8 lg:grid-cols-[minmax(0,1fr)_18rem] lg:gap-12"
            >
              <div className="min-w-0">
                <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
                  <span className="font-label text-[11px] tracking-[0.08em] text-primary uppercase">
                    {p.scope}
                  </span>
                  <span className="font-label text-[11px] text-muted-foreground">
                    {String(i + 1).padStart(2, '0')} / {String(projects.length).padStart(2, '0')}
                  </span>
                </div>
                <h2 className="mt-2 font-display text-xl font-semibold text-foreground sm:text-2xl">
                  {p.title}
                </h2>
                <p className="mt-1 text-sm font-medium text-foreground/80">{p.client}</p>
                <p className="mt-4 max-w-2xl text-[0.95rem] leading-7 text-muted-foreground">
                  {p.detail}
                </p>
              </div>

              <div className="self-start rounded-md border border-border bg-card p-4">
                <p className="font-label text-[10px] tracking-[0.08em] text-muted-foreground uppercase">
                  {p.path ? 'Version path' : 'Landscape'}
                </p>
                <div className="mt-2">
                  {p.path ? (
                    <VersionPath path={p.path} />
                  ) : (
                    <p className="text-sm leading-6 text-foreground">{p.landscape}</p>
                  )}
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="bg-background">
        <div className="mx-auto flex max-w-content flex-col gap-4 px-gutter py-12 sm:flex-row sm:items-center sm:justify-between">
          <p className="max-w-xl text-[0.95rem] leading-7 text-foreground">
            The runbooks behind this work are in the SAP Library — two of them free.
          </p>
          <Button asChild variant="outline" className="h-11 shrink-0">
            <Link to="/library">
              Open the SAP Library
              <ArrowRight aria-hidden="true" className="size-4" strokeWidth={1.5} />
            </Link>
          </Button>
        </div>
      </section>
    </main>
  )
}
