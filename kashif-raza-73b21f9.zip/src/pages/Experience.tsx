import { Link } from 'react-router'
import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { roles } from '@/data/site'

export default function Experience() {
  return (
    <main>
      <section className="bg-background">
        <div className="mx-auto max-w-content px-gutter pt-12 pb-10 md:pt-16">
          <h1 className="font-display text-[length:var(--hero-mobile)] font-semibold tracking-[-0.025em] sm:text-[length:var(--hero-size)] sm:leading-[1.04]">
            Experience
          </h1>
          <p className="mt-4 max-w-2xl text-[0.975rem] leading-7 text-muted-foreground">
            Three years in SAP Basis, across two consultancies — from associate administrator to
            running ECC and S/4HANA landscapes day to day.
          </p>
        </div>
      </section>

      <section className="bg-card">
        <div className="mx-auto max-w-content px-gutter py-section">
          {/* The timeline is one sequence, so it carries the blue rule. */}
          <ol className="relative space-y-8 border-l border-primary/30 pl-5 sm:space-y-10 sm:pl-8">
            {roles.map((r) => (
              <li key={r.company} className="relative">
                <span
                  aria-hidden="true"
                  className={
                    r.current
                      ? 'absolute top-2 -left-[1.44rem] size-2.5 rounded-full bg-primary ring-4 ring-card sm:-left-[2.44rem]'
                      : 'absolute top-2 -left-[1.44rem] size-2.5 rounded-full border-2 border-primary/50 bg-card sm:-left-[2.44rem]'
                  }
                />
                <div className="rounded-lg bg-background p-5 sm:p-7">
                  <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1">
                    <h2 className="font-display text-lg font-semibold text-foreground sm:text-xl">
                      {r.title}
                    </h2>
                    <p className="font-label text-xs tracking-[0.04em] text-muted-foreground">
                      {r.from} — {r.to}
                    </p>
                  </div>
                  <p className="mt-1 text-sm font-medium text-primary">{r.company}</p>
                  <ul className="mt-4 space-y-2">
                    {r.points.map((pt) => (
                      <li
                        key={pt}
                        className="flex gap-3 text-[0.95rem] leading-7 text-muted-foreground"
                      >
                        <span aria-hidden="true" className="mt-[0.7rem] h-px w-3 shrink-0 bg-border" />
                        <span>{pt}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="bg-background">
        <div className="mx-auto flex max-w-content flex-col gap-4 px-gutter py-12 sm:flex-row sm:items-center sm:justify-between">
          <p className="max-w-xl text-[0.95rem] leading-7 text-foreground">
            The dates, the titles and the work, on one page for a hiring manager.
          </p>
          <Button asChild className="h-11 shrink-0">
            <Link to="/resume">
              View the resume
              <ArrowRight aria-hidden="true" className="size-4" strokeWidth={1.5} />
            </Link>
          </Button>
        </div>
      </section>
    </main>
  )
}
