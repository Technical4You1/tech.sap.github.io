import { ExternalLink, MessageCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { person } from '@/data/site'

const rows = [
  { label: 'Email', node: <a className="font-medium text-primary underline underline-offset-4 hover:text-primary-hover" href={`mailto:${person.email}`}>{person.email}</a> },
  { label: 'Mobile / WhatsApp', node: (
    <>
      <a className="font-medium text-primary underline underline-offset-4 hover:text-primary-hover" href={`tel:${person.phoneHref}`}>{person.phone}</a>
      <span className="mx-2 text-border">|</span>
      <a className="font-medium text-primary underline underline-offset-4 hover:text-primary-hover" href={person.whatsapp} target="_blank" rel="noopener noreferrer">Message on WhatsApp</a>
    </>
  ) },
  { label: 'Current location', node: <span>{person.currentLocation}</span> },
  { label: 'Home address', node: <span>{person.location}</span> },
  { label: 'LinkedIn', node: (
    <a className="font-medium text-primary underline underline-offset-4 hover:text-primary-hover" href={person.linkedin} target="_blank" rel="noopener noreferrer">linkedin.com/in/technical4you</a>
  ) },
]

export default function Contact() {
  return (
    <main>
      <section className="bg-navy text-navy-ink">
        <div className="mx-auto max-w-content px-gutter pt-12 pb-14 md:pt-16 md:pb-16">
          <h1 className="max-w-2xl font-display text-[length:var(--hero-mobile)] font-semibold tracking-[-0.025em] sm:text-[length:var(--hero-size)] sm:leading-[1.04]">
            Get in touch
          </h1>
          <p className="mt-4 max-w-2xl text-[0.975rem] leading-7 text-navy-muted">
            For freelance SAP Basis support, HANA administration or S/4HANA upgrade planning,
            message on WhatsApp or send an email. Hiring? The resume is one click away.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg" className="h-12 px-5">
              <a href={person.whatsapp} target="_blank" rel="noopener noreferrer">
                <MessageCircle aria-hidden="true" className="size-4" strokeWidth={1.5} />
                Message on WhatsApp
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="h-12 border-navy-line bg-transparent px-5 text-navy-ink hover:bg-navy-raised hover:text-navy-ink"
            >
              <a href={person.linkedin} target="_blank" rel="noopener noreferrer">
                <ExternalLink aria-hidden="true" className="size-4" strokeWidth={1.5} />
                LinkedIn
              </a>
            </Button>
          </div>
        </div>
      </section>

      <section className="bg-background">
        <div className="mx-auto max-w-content px-gutter py-section">
          <h2 className="font-display text-2xl font-semibold sm:text-3xl">Details</h2>
          <dl className="mt-6 divide-y divide-border border-t border-border">
            {rows.map((r) => (
              <div key={r.label} className="grid gap-1 py-4 sm:grid-cols-[14rem_1fr] sm:gap-6 sm:py-5">
                <dt className="font-label text-[11px] tracking-[0.08em] text-muted-foreground uppercase sm:pt-1">
                  {r.label}
                </dt>
                <dd className="text-[0.95rem] leading-7 text-foreground">{r.node}</dd>
              </div>
            ))}
          </dl>
          <p className="mt-8 max-w-xl text-sm leading-6 text-muted-foreground">
            Replies usually come within a working day. Include the landscape, the versions and the
            window you need and the first answer can be a real one.
          </p>
        </div>
      </section>
    </main>
  )
}
