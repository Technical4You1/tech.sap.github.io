import { ArrowRight, ExternalLink } from 'lucide-react'
import { useEffect } from 'react'
import { Link } from 'react-router'
import { Meta } from '@/components/Meta'
import { Button } from '@/components/ui/button'
import { person, premium, requestHref, runbooks, type Runbook } from '@/data/site'

const freeRunbooks: Runbook[] = runbooks.filter((r) => r.tier === 'free')
const upcomingRunbooks: Runbook[] = runbooks.filter((r) => r.tier === 'soon')
const premiumRunbooks = premium

/* The library: a numbered build order on white, then the premium runbooks as a
   table on the navy band. Nothing here is a card grid. */
export default function Library() {
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <>
      <div className="bg-background text-foreground">
      <Meta
        title="SAP Library — free and premium Basis runbooks | Kashif Raza"
        description="Free step-by-step SOPs for SAP HANA installation and application server setup, plus premium runbooks for S/4HANA upgrades, daily health checks and Azure VM builds — requested by email."
      />
      <main id="main">
        <section className="border-b border-border px-gutter py-section">
          <div className="mx-auto max-w-content">
            <p className="font-label text-xs tracking-[0.1em] text-muted-foreground uppercase">SAP Library</p>

            <h1 className="mt-3 max-w-2xl font-display text-4xl leading-[1.1] font-semibold tracking-[-0.02em] sm:text-5xl">
              The runbooks I use on live systems
            </h1>
            <p className="mt-4 max-w-xl text-base leading-7 text-muted-foreground">
              Two are free to open. The rest are written as working documents and sent on request.
            </p>
          </div>
        </section>

        <section className="px-gutter py-section" aria-labelledby="free-heading">
          <div className="mx-auto max-w-content">
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <h2 id="free-heading" className="font-display text-2xl font-semibold tracking-[-0.02em] sm:text-3xl">
                Free runbooks
              </h2>
              <p className="font-label text-xs text-muted-foreground">In build order — database first, then the server</p>
            </div>

            <ol className="mt-8 space-y-4">
              {freeRunbooks.map((r) => (
                <li
                  key={r.slug}
                  className="grid gap-4 rounded-lg bg-card p-5 sm:grid-cols-[3rem_1fr_auto] sm:items-start sm:gap-6 sm:p-6"
                >
                  <span className="font-label text-sm text-[length:0.9rem] text-muted-foreground">
                    {String(r.step).padStart(2, '0')}
                  </span>
                  <div className="min-w-0">
                    <span className="inline-block rounded-sm border border-success-line bg-success-soft px-1.5 py-0.5 font-label text-[11px] tracking-[0.08em] text-success uppercase">
                      Free
                    </span>
                    <h3 className="mt-2 font-display text-lg font-medium text-foreground">{r.title}</h3>
                    <p className="mt-1.5 max-w-2xl text-sm leading-6 text-muted-foreground">{r.summary}</p>
                  </div>
                  <Button asChild variant="outline" className="h-11 justify-self-start sm:justify-self-end">
                    <a href={r.href} target="_blank" rel="noopener noreferrer">
                      View SOP
                      <ExternalLink aria-hidden="true" className="size-4" strokeWidth={1.5} />
                    </a>
                  </Button>
                </li>
              ))}
            </ol>

            <div className="mt-10 rounded-lg border border-border p-5 sm:p-6">
              <h3 className="font-display text-base font-medium">In preparation</h3>
              <p className="mt-1 text-sm leading-6 text-muted-foreground">
                Further SOPs are being written. Nothing to open yet.
              </p>
              <ul className="mt-4 grid gap-x-8 gap-y-2 sm:grid-cols-2">
                {upcomingRunbooks.map((u) => (
                  <li key={u.step} className="flex items-baseline gap-3 font-label text-xs text-muted-foreground">
                    <span>{String(u.step).padStart(2, '0')}</span>
                    <span className="font-sans text-sm text-muted-foreground">{u.title}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <section className="bg-navy px-gutter py-section text-navy-ink" aria-labelledby="premium-heading">
          <div className="mx-auto max-w-content">
            <p className="font-label text-xs tracking-[0.1em] text-gold-ink uppercase">Premium</p>
            <h2 id="premium-heading" className="mt-3 font-display text-2xl font-semibold tracking-[-0.02em] sm:text-3xl">
              Premium runbooks
            </h2>
            <p className="mt-3 max-w-xl text-base leading-7 text-navy-muted">
              Email for the one you need and I will send it back with the price. Each request names its own runbook.
            </p>

            <div className="mt-8 hidden overflow-x-auto md:block">
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="border-y border-navy-line">
                    <th scope="col" className="py-3 pr-6 font-label text-xs font-normal tracking-[0.08em] text-navy-muted uppercase">Runbook</th>
                    <th scope="col" className="py-3 pr-6 font-label text-xs font-normal tracking-[0.08em] text-navy-muted uppercase">Pages</th>
                    <th scope="col" className="py-3 pr-6 font-label text-xs font-normal tracking-[0.08em] text-navy-muted uppercase">What it covers</th>
                    <th scope="col" className="py-3 text-right font-label text-xs font-normal tracking-[0.08em] text-navy-muted uppercase">Request</th>
                  </tr>
                </thead>
                <tbody>
                  {premiumRunbooks.map((p) => (
                    <tr key={p.slug} className="border-b border-navy-line align-top">
                      <th scope="row" className="w-[26%] py-5 pr-6 text-left align-top font-display text-base font-medium text-navy-ink">
                        <span className="mb-1.5 block w-fit rounded-sm border border-gold/70 px-1.5 py-0.5 font-label text-[11px] tracking-[0.08em] whitespace-nowrap text-gold-ink uppercase">
                          Premium
                        </span>
                        {p.title}
                      </th>
                      <td className="w-[7ch] py-5 pr-6 font-label text-sm text-navy-muted">{p.pages}</td>
                      <td className="py-5 pr-6 text-sm leading-6 text-navy-muted">{p.covers}</td>
                      <td className="py-5 text-right">
                        <a
                          href={requestHref(p.title)}
                          className="inline-flex min-h-11 items-center gap-1.5 text-sm font-medium text-gold-ink underline decoration-gold/60 underline-offset-4 hover:decoration-gold focus-visible:rounded-sm focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold"
                        >
                          Email for it
                          <ArrowRight aria-hidden="true" className="size-4" strokeWidth={1.5} />
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <ul className="mt-8 space-y-4 md:hidden">
              {premiumRunbooks.map((p) => (
                <li key={p.slug} className="rounded-lg border border-navy-line bg-navy p-5">
                  <span className="inline-block rounded-sm border border-gold/70 bg-navy px-1.5 py-0.5 font-label text-[11px] tracking-[0.08em] text-gold-ink uppercase">
                    Premium
                  </span>
                  <h3 className="mt-2 font-display text-base font-medium text-navy-ink">{p.title}</h3>
                  <p className="mt-1 font-label text-xs text-navy-muted">{p.pages} pages</p>
                  <p className="mt-2 text-sm leading-6 text-navy-muted">{p.covers}</p>
                  <a
                    href={requestHref(p.title)}
                    className="mt-3 inline-flex min-h-11 items-center gap-1.5 text-sm font-medium text-gold-ink underline decoration-gold/60 underline-offset-4"
                  >
                    Email for it
                    <ArrowRight aria-hidden="true" className="size-4" strokeWidth={1.5} />
                  </a>
                </li>
              ))}
            </ul>

            <p className="mt-8 font-label text-xs text-navy-muted">
              Prices on request — email{' '}
              <a href={`mailto:${person.email}`} className="text-navy-ink underline underline-offset-4">
                {person.email}
              </a>
              .
            </p>

            <p className="mt-10 text-sm text-navy-muted">
              Looking for the free ones?{' '}
              <Link to="/contact" className="text-navy-ink underline underline-offset-4">
                Get in touch
              </Link>
              .
            </p>
          </div>
        </section>
      </main>
      </div>
    </>
  )
}
