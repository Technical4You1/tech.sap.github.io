import { Link } from 'react-router'
import { Button } from '@/components/ui/button'

export default function NotFound() {
  return (
    <main className="mx-auto grid min-h-[60vh] max-w-content place-items-center px-gutter py-20 text-center">
      <div>
        <p className="font-label text-xs tracking-[0.16em] text-primary uppercase">
          404 · no such system
        </p>
        <h1 className="mt-3 font-display text-3xl font-semibold md:text-4xl">
          This page does not exist
        </h1>
        <p className="mx-auto mt-3 max-w-prose text-muted-foreground">
          The address may be mistyped, or the page may have moved. The library and the portfolio are
          both still where they were.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Button asChild className="h-11">
            <Link to="/">Back to home</Link>
          </Button>
          <Button asChild variant="outline" className="h-11">
            <Link to="/library">SAP Library</Link>
          </Button>
        </div>
      </div>
    </main>
  )
}
