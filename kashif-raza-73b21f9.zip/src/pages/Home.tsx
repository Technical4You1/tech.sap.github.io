import { Link } from 'react-router'
import { ArrowRight, ExternalLink, FileDown, MessageCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { LandscapePanel } from '@/components/LandscapePanel'
import { facts, person, projects, skills } from '@/data/site'

const freelance = [
  'SAP Basis support',
  'HANA administration',
  'S/4HANA upgrade planning',
]

export default function Home() {
  return (
    <main>
      {/* First screen: navy ground, name largest, the landscape beside it. */}
      <section className="relative overflow-x-clip bg-navy text-navy-ink">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 overflow-hidden opacity-[0.35]"
          style={{
            backgroundImage:
              'radial-gradient(color-mix(in oklch, var(--navy-ink) 14%, transparent) 1px, transparent 1px)',
            backgroundSize: '22px 22px',
            maskImage: 'linear-gradient(to bottom, black, transparent 70%)',
          }}
        />
        <div className="relative mx-auto grid max-w-content items-center gap-10 px-gutter pt-12 pb-14 md:pt-16 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] lg:gap-14 lg:pt-20 lg:pb-20">
          <div>
            <p className="font-label text-xs tracking-[0.1em] text-primary-soft/80 uppercase">
              SAP Basis · Freelance available
            </p>
            <h1 className="mt-4 font-display text-[length:var(--hero-mobile)] font-semibold tracking-[-0.025em] text-balance sm:text-[length:var(--hero-size)] sm:leading-[1.04]">
              Kashif Raza
            </h1>
            <p className="mt-3 font-label text-sm tracking-[0.02em] text-navy-muted sm:text-base">
              {person.role} <span className="text-navy-line">|</span> SAP HANA{' '}
              <span className="text-navy-line">|</span> S/4HANA
            </p>
            <p className="mt-5 max-w-xl text-[0.975rem] leading-7 text-navy-muted">
              Three years administering SAP landscapes — system monitoring, HANA database
              management, upgrades and troubleshooting across S/4HANA, ECC and Linux. Available
              for freelance SAP Basis support.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button asChild size="lg" className="h-12 px-5 text-[0.95rem]">
                <a href={person.whatsapp} target="_blank" rel="noopener noreferrer">
                  <MessageCircle aria-hidden="true" className="size-4" strokeWidth={1.5} />
                  Message on WhatsApp
                </a>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="h-12 border-navy-line bg-transparent px-5 text-[0.95rem] text-navy-ink hover:bg-navy-raised hover:text-navy-ink"
              >
                <Link to="/resume">
                  <FileDown aria-hidden="true" className="size-4" strokeWidth={1.5} />
                  View resume
                </Link>
              </Button>
            </div>

            <a
              href={person.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-5 inline-flex min-h-11 items-center gap-1.5 text-sm text-navy-muted underline decoration-navy-line underline-offset-4 transition-colors hover:text-navy-ink hover:decoration-navy-ink"
            >
              LinkedIn profile
              <ExternalLink aria-hidden="true" className="size-3.5" strokeWidth={1.5} />
            </a>
          </div>

          <LandscapePanel />
        </div>
      </section>

      {/* One row of facts — the page's first light ground */}
      <section className="border-b border-border bg-background">
        <dl className="mx-auto grid max-w-content divide-y divide-border px-gutter sm:grid-cols-3 sm:divide-x sm:divide-y-0">
          {facts.map((f) => (
            <div key={f.label} className="py-5 sm:px-6 sm:first:pl-0 sm:last:pr-0">
              <dt className="font-label text-[11px] tracking-[0.08em] text-muted-foreground uppercase">
                {f.label}
              </dt>
              <dd className="mt-1 font-display text-lg font-medium text-foreground">{f.value}</dd>
            </div>
          ))}
        </dl>
      </section>

      {/* Skills: a set, so a tag cloud and no numbers */}
      <section className="bg-card">
        <div className="mx-auto max-w-content px-gutter py-section">
          <div className="grid gap-8 lg:grid-cols-[18rem_1fr] lg:gap-16">
            <div>
              <h2 className="font-display text-2xl font-semibold sm:text-3xl">Core skills</h2>
              <p className="mt-3 max-w-sm text-sm leading-6 text-muted-foreground">
                The stack this work actually runs on, from the application server down to the
                host.
              </p>
            </div>
            <ul className="flex flex-wrap gap-2 self-start">
              {skills.map((s) => (
                <li
                  key={s}
                  className="rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground"
                >
                  {s}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Selected projects as horizontal case rows, not cards */}
      <section className="bg-background">
        <div className="mx-auto max-w-content px-gutter py-section">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <h2 className="font-display text-2xl font-semibold sm:text-3xl">
              Selected projects
            </h2>
            <Link
              to="/portfolio"
              className="inline-flex min-h-11 items-center gap-1.5 text-sm font-medium text-primary underline-offset-4 hover:underline"
            >
              All three in detail
              <ArrowRight aria-hidden="true" className="size-4" strokeWidth={1.5} />
            </Link>
          </div>

          <ol className="mt-8 border-t border-border">
            {projects.map((p) => (
              <li key={p.slug} className="border-b border-border">
                <Link
                  to="/portfolio"
                  className="group grid gap-2 py-6 outline-none transition-colors hover:bg-card focus-visible:bg-card md:grid-cols-[7rem_minmax(0,1fr)_auto] md:items-baseline md:gap-6"
                >
                  <span className="font-label text-[11px] tracking-[0.08em] text-primary uppercase">
                    {p.scope}
                  </span>
                  <span className="min-w-0">
                    <span className="block font-display text-lg font-medium text-foreground">
                      {p.title} <span className="text-muted-foreground">·</span> {p.client}
                    </span>
                    <span className="mt-1 block text-sm leading-6 text-muted-foreground">
                      {p.summary}
                    </span>
                    <span className="mt-2 block font-label text-[11px] text-foreground/70">
                      {p.path ? p.path.join('  →  ') : p.landscape}
                    </span>
                  </span>
                  <span className="hidden shrink-0 self-center font-label text-[11px] text-muted-foreground md:block">
                    {p.landscape}
                  </span>
                </Link>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Freelance strip on the pale panel */}
      <section className="bg-card">
        <div className="mx-auto max-w-content px-gutter py-section">
          <div className="grid gap-8 rounded-xl bg-background p-6 sm:p-10 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-center lg:gap-12">
            <div>
              <h2 className="font-display text-2xl font-semibold sm:text-3xl">
                Open to freelance work
              </h2>
              <p className="mt-3 max-w-xl text-[0.975rem] leading-7 text-muted-foreground">
                Taking on SAP Basis engagements alongside the day job. If you have a landscape
                that needs a hand, send it over.
              </p>
              <ul className="mt-5 flex flex-wrap gap-x-6 gap-y-2">
                {freelance.map((f) => (
                  <li
                    key={f}
                    className="flex items-center gap-2 text-sm text-foreground before:h-1 before:w-1 before:rounded-full before:bg-primary"
                  >
                    {f}
                  </li>
                ))}
              </ul>
            </div>
            <Button asChild size="lg" className="h-12 px-5 text-[0.95rem]">
              <Link to="/contact">
                Send a project request
                <ArrowRight aria-hidden="true" className="size-4" strokeWidth={1.5} />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}
