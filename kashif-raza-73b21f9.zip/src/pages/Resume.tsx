import { useState } from 'react'
import { ExternalLink, FileDown } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { person } from '@/data/site'

export default function Resume() {
  const [loaded, setLoaded] = useState(false)

  return (
    <main>
      <section className="bg-background">
        <div className="mx-auto max-w-content px-gutter pt-12 pb-8 md:pt-16">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <h1 className="font-display text-[length:var(--hero-mobile)] font-semibold tracking-[-0.025em] sm:text-[length:var(--hero-size)] sm:leading-[1.04]">
                Resume
              </h1>
              <p className="mt-3 max-w-xl text-[0.975rem] leading-7 text-muted-foreground">
                One page: roles, dates, projects and skills. Read it here or take a copy.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Button asChild className="h-11">
                <a href={person.resume} download>
                  <FileDown aria-hidden="true" className="size-4" strokeWidth={1.5} />
                  Download PDF
                </a>
              </Button>
              <Button asChild variant="outline" className="h-11">
                <a href={person.resume} target="_blank" rel="noopener noreferrer">
                  Open in a new tab
                  <ExternalLink aria-hidden="true" className="size-4" strokeWidth={1.5} />
                </a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-card">
        <div className="mx-auto max-w-content px-gutter py-section">
          <div className="relative overflow-hidden rounded-lg border border-border bg-background">
            {/* Holds the frame's shape while the PDF loads, so nothing jumps. */}
            {!loaded && (
              <div className="absolute inset-0 flex items-center justify-center bg-card">
                <p className="font-label text-[11px] tracking-[0.08em] text-muted-foreground uppercase">
                  Loading resume…
                </p>
              </div>
            )}
            <object
              data={person.resume}
              type="application/pdf"
              title="Kashif Raza's resume, as a PDF"
              onLoad={() => setLoaded(true)}
              className="relative block h-[75vh] min-h-[28rem] w-full"
            >
              <div className="p-8 text-center">
                <p className="text-sm text-muted-foreground">
                  This browser will not display the PDF inline.
                </p>
                <p className="mt-3">
                  <a
                    href={person.resume}
                    className="inline-flex min-h-11 items-center font-medium text-primary underline underline-offset-4"
                  >
                    Open the resume PDF
                  </a>
                </p>
              </div>
            </object>
          </div>
          <p className="mt-4 font-label text-[11px] text-muted-foreground">
            PDF · opens in the browser’s own viewer
          </p>
        </div>
      </section>
    </main>
  )
}
