import { cn } from '@/lib/utils'

/* The mark: a KR monogram in the heading face, white on navy, with a blue
   system light at its corner. The name is always this mark, never plain text
   beside it at full size. */
export function BrandMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      aria-hidden="true"
      focusable="false"
      className={cn('size-8', className)}
    >
      <rect width="32" height="32" rx="7" fill="var(--navy)" />
      <text
        x="15"
        y="21.5"
        textAnchor="middle"
        fill="var(--navy-ink)"
        fontFamily="var(--font-heading)"
        fontSize="13.5"
        fontWeight="600"
        letterSpacing="-0.4"
      >
        KR
      </text>
      <circle cx="25" cy="7.5" r="2.6" fill="var(--primary)" stroke="var(--navy)" strokeWidth="1" />
    </svg>
  )
}

/* Small sizes show the monogram alone; the wordmark joins it from `sm` up, so
   a 360 bar holds a mark, a menu button and a message button. */
export function Brand({ className }: { className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <BrandMark className="size-9 shrink-0" />
      <span className="hidden font-display text-lg font-semibold tracking-tight sm:inline">
        Kashif Raza
      </span>
    </span>
  )
}
