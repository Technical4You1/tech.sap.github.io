import { useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router'
import { MessageCircle, Menu } from 'lucide-react'
import { Brand } from '@/components/Brand'
import { Button } from '@/components/ui/button'
import { Sheet, SheetClose, SheetContent, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import { cn } from '@/lib/utils'
import { person } from '@/data/site'

const links = [
  { to: '/library', label: 'SAP Library' },
  { to: '/portfolio', label: 'Portfolio' },
  { to: '/experience', label: 'Experience' },
  { to: '/resume', label: 'Resume' },
  { to: '/contact', label: 'Contact' },
]

/* The shell is a navy bar: mark left, the five sections, then the library's
   premium half in gold and the message button in blue. At 360 the links move
   into a sheet and the message button stays. */
export function Header() {
  const [open, setOpen] = useState(false)
  const { pathname } = useLocation()

  return (
    <header className="sticky top-0 z-40 bg-navy text-navy-ink">
      <div className="mx-auto flex h-16 max-w-content items-center gap-4 px-gutter">
        <Link
          to="/"
          aria-label="Kashif Raza — home"
          className="flex min-h-11 items-center rounded-md outline-none focus-visible:ring-2 focus-visible:ring-primary-foreground/70"
        >
          <Brand />
        </Link>

        <nav aria-label="Sections" className="ml-auto hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                cn(
                  'rounded-md px-3 py-2 text-sm text-navy-muted transition-colors hover:text-navy-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring',
                  isActive && 'text-navy-ink hover:text-navy-ink',
                )
              }
            >
              {l.label}
            </NavLink>
          ))}
          <NavLink
            to="/library#premium"
            className="ml-1 rounded-md border border-gold/60 px-3 py-2 font-label text-xs tracking-[0.06em] text-gold uppercase transition-colors hover:border-gold hover:bg-gold/10 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold"
          >
            Premium
          </NavLink>
        </nav>

        <div className="ml-auto flex items-center gap-2 lg:ml-3">
          <Button asChild className="h-11 px-4 max-sm:px-3">
            <a href={person.whatsapp} target="_blank" rel="noopener noreferrer">
              <MessageCircle aria-hidden="true" className="size-4" strokeWidth={1.5} />
              <span className="max-sm:sr-only">Message me</span>
            </a>
          </Button>

          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="size-11 text-navy-ink hover:bg-navy-raised hover:text-navy-ink lg:hidden"
                aria-label="Open menu"
              >
                <Menu className="size-5" strokeWidth={1.5} aria-hidden="true" />
              </Button>
            </SheetTrigger>
            <SheetContent
              side="right"
              className="w-[86vw] max-w-xs gap-0 border-navy-line bg-navy text-navy-ink"
            >
              <SheetTitle className="sr-only">Menu</SheetTitle>
              <div className="px-5 pt-5">
                <Brand />
              </div>
              <nav aria-label="Sections" className="mt-6 flex flex-col px-3">
                <SheetClose asChild>
                  <Link
                    to="/"
                    className={cn(
                      'rounded-md px-3 py-3 text-base',
                      pathname === '/' ? 'text-navy-ink' : 'text-navy-muted',
                    )}
                  >
                    Home
                  </Link>
                </SheetClose>
                {links.map((l) => (
                  <SheetClose key={l.to} asChild>
                    <Link
                      to={l.to}
                      className={cn(
                        'rounded-md px-3 py-3 text-base',
                        pathname === l.to ? 'text-navy-ink' : 'text-navy-muted',
                      )}
                    >
                      {l.label}
                    </Link>
                  </SheetClose>
                ))}
                <SheetClose asChild>
                  <Link to="/library#premium" className="mt-2 px-3 py-3 font-label text-xs tracking-[0.08em] text-gold uppercase">
                    Premium Library
                  </Link>
                </SheetClose>
              </nav>
              <p className="mt-auto px-5 pb-6 font-label text-[11px] text-navy-muted">
                {person.email}
              </p>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}

export function Footer() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto flex max-w-content flex-col gap-6 px-gutter py-10 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Brand />
        </div>
        <nav aria-label="Footer" className="flex flex-wrap gap-x-5 gap-y-2 text-sm text-muted-foreground">
          <Link className="hover:text-foreground" to="/library">SAP Library</Link>
          <Link className="hover:text-foreground" to="/portfolio">Portfolio</Link>
          <Link className="hover:text-foreground" to="/contact">Contact</Link>
          <a className="hover:text-foreground" href={person.linkedin} target="_blank" rel="noopener noreferrer">
            LinkedIn
          </a>
        </nav>
        <p className="font-label text-[11px] tracking-[0.04em] text-muted-foreground">
          © {new Date().getFullYear()} Kashif Raza
        </p>
      </div>
    </footer>
  )
}
