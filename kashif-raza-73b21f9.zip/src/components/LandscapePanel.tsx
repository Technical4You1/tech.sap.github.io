/* The centrepiece: an SAP landscape dashboard drawn in code. Sample figures —
   it is an illustration of the work, not a report from a client system — so it
   carries status and shape, not a claim about any particular landscape. */

type System = {
  sid: string
  role: string
  state: 'Running' | 'Upgrading'
  hana: number // % of total memory in use
}

const systems: System[] = [
  { sid: 'DEV', role: 'Development', state: 'Running', hana: 38 },
  { sid: 'QAS', role: 'Quality', state: 'Upgrading', hana: 54 },
  { sid: 'PRD', role: 'Production', state: 'Running', hana: 61 },
]

function StateDot({ state }: { state: System['state'] }) {
  const upgrading = state === 'Upgrading'
  return (
    <span className="inline-flex items-center gap-1.5">
      <span
        aria-hidden="true"
        className={
          upgrading
            ? 'size-1.5 animate-pulse rounded-full bg-primary'
            : 'size-1.5 rounded-full bg-success'
        }
      />
      <span className={upgrading ? 'text-primary' : 'text-success'}>{state}</span>
    </span>
  )
}

function Meter({ value }: { value: number }) {
  return (
    <div
      role="img"
      aria-label={`${value} percent of HANA memory in use`}
      className="h-1.5 w-full overflow-hidden rounded-full bg-navy-line/70"
    >
      <div className="h-full rounded-full bg-primary" style={{ width: `${value}%` }} />
    </div>
  )
}

export function LandscapePanel() {
  return (
    <figure className="relative">
      {/* soft light behind the panel, from the token */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(closest-side, color-mix(in oklch, var(--primary) 38%, transparent), transparent)',
        }}
      />
      <div className="overflow-hidden rounded-xl border border-navy-line bg-navy-raised/70 shadow-raised backdrop-blur">
        <div className="flex items-center justify-between gap-3 border-b border-navy-line px-4 py-3">
          <p className="font-label text-[11px] tracking-[0.08em] text-navy-muted uppercase">
            Landscape status
          </p>
          <p className="font-label text-[11px] text-navy-muted">
            <span className="text-navy-ink">03</span> systems
          </p>
        </div>

        <ul className="divide-y divide-navy-line">
          {systems.map((s) => (
            <li key={s.sid} className="grid grid-cols-[3.25rem_1fr] gap-x-4 gap-y-2 px-4 py-3.5">
              <p className="font-label text-base leading-6 font-medium text-navy-ink">{s.sid}</p>
              <div className="min-w-0">
                <div className="flex flex-wrap items-baseline justify-between gap-x-3 font-label text-[11px] text-navy-muted">
                  <span>{s.role}</span>
                  <StateDot state={s.state} />
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <span className="font-label text-[10px] tracking-[0.06em] text-navy-muted uppercase">
                    HANA
                  </span>
                  <Meter value={s.hana} />
                  <span className="w-8 shrink-0 text-right font-label text-[11px] text-navy-ink">
                    {s.hana}%
                  </span>
                </div>
              </div>
            </li>
          ))}
        </ul>

        {/* The upgrade in progress — a real sequence, so it is numbered. */}
        <div className="border-t border-navy-line bg-navy/40 px-4 py-4">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <p className="font-label text-[11px] tracking-[0.08em] text-navy-muted uppercase">
              S/4HANA upgrade · QAS
            </p>
            <p className="font-label text-[11px] text-navy-ink">
              1709 <span className="text-navy-muted">→</span> 2025
            </p>
          </div>
          <div
            role="img"
            aria-label="Upgrade run in phase 2 of 3: downtime COMPLETED, SUM running at 64 percent, activation pending"
            className="mt-3 grid grid-cols-3 gap-2"
          >
            {[
              { n: '01', name: 'Downtime', state: 'done' },
              { n: '02', name: 'SUM', state: 'run', pct: 64 },
              { n: '03', name: 'Activation', state: 'wait' },
            ].map((p) => (
              <div key={p.n} className="min-w-0">
                <div className="h-1 w-full overflow-hidden rounded-full bg-navy-line">
                  <div
                    className={
                      p.state === 'wait'
                        ? 'h-full w-0 bg-primary'
                        : p.state === 'done'
                          ? 'h-full w-full bg-success'
                          : 'h-full bg-primary'
                    }
                    style={p.state === 'run' ? { width: `${p.pct}%` } : undefined}
                  />
                </div>
                <p className="mt-2 font-label text-[10px] tracking-[0.04em] text-navy-muted uppercase">
                  <span className="text-navy-ink">{p.n}</span> {p.name}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-3 divide-x divide-navy-line border-t border-navy-line">
          {[
            { k: 'Jobs', v: '0 failed', s: 'ok' },
            { k: 'Work proc.', v: 'All free', s: 'ok' },
            { k: 'Uptime', v: '99.9%', s: 'ok' },
          ].map((b) => (
            <div key={b.k} className="px-3 py-3 text-center">
              <p className="font-label text-[10px] tracking-[0.06em] text-navy-muted uppercase">
                {b.k}
              </p>
              <p className="mt-1 font-label text-xs text-navy-ink">{b.v}</p>
            </div>
          ))}
        </div>
      </div>
      <figcaption className="mt-3 font-label text-[11px] text-navy-muted">
        Sample landscape, drawn to show the work.
      </figcaption>
    </figure>
  )
}
