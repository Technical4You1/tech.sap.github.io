import { lazy, Suspense } from 'react'
import { Route, Routes } from 'react-router'
import Home from '@/pages/Home'
import { Meta } from '@/components/Meta'
import { Footer, Header } from '@/components/SiteChrome'

// Routes are code-split so the first paint carries only the landing page.
const Library = lazy(() => import('@/pages/Library'))
const Portfolio = lazy(() => import('@/pages/Portfolio'))
const Experience = lazy(() => import('@/pages/Experience'))
const Resume = lazy(() => import('@/pages/Resume'))
const Contact = lazy(() => import('@/pages/Contact'))
const NotFound = lazy(() => import('@/pages/NotFound'))

// Holds the page's height while a route chunk loads, so the footer does not jump up.
function RouteFallback() {
  return (
    <main className="mx-auto min-h-[60vh] max-w-content px-gutter py-24">
      <p className="font-label text-[11px] tracking-[0.08em] text-muted-foreground uppercase">
        Loading…
      </p>
    </main>
  )
}

/* The shell: a navy bar over every route, and a footer that carries the mark
   and the direct links. Each page owns its own `main`. */
export default function App() {
  return (
    <div className="flex min-h-dvh flex-col">
      <Header />
      <div className="flex-1">
        <Suspense fallback={<RouteFallback />}>
          <Routes>
            <Route
              index
              element={
                <>
                  <Meta
                    title="Kashif Raza — SAP Basis Consultant, SAP HANA & S/4HANA"
                    description="SAP Basis consultant with three years on SAP HANA, S/4HANA and ECC landscapes — upgrades, DR builds and monitoring, plus free SAP Basis runbooks and freelance support."
                  />
                  <Home />
                </>
              }
            />
            <Route
              path="library"
              element={
                <>
                  <Meta
                    title="SAP Library — free and premium Basis runbooks"
                    description="Free SAP Basis runbooks for HANA installation and application server setup, plus longer premium runbooks on S/4HANA upgrades, health checks and Azure practice systems."
                  />
                  <Library />
                </>
              }
            />
            <Route
              path="portfolio"
              element={
                <>
                  <Meta
                    title="Portfolio — S/4HANA upgrades and DR builds"
                    description="S/4HANA upgrades from 1709 and 2022, and a disaster-recovery build off a replicated HANA database, for manufacturers and a large business group."
                  />
                  <Portfolio />
                </>
              }
            />
            <Route
              path="experience"
              element={
                <>
                  <Meta
                    title="Experience — SAP Basis roles and timelines"
                    description="SAP Basis at Excelligent Consulting Services from December 2025, and associate SAP Basis at Progression Infonet from November 2023 to December 2025."
                  />
                  <Experience />
                </>
              }
            />
            <Route
              path="resume"
              element={
                <>
                  <Meta
                    title="Resume — Kashif Raza, SAP Basis Consultant"
                    description="Kashif Raza's resume as a PDF: three years of SAP Basis, SAP HANA administration and S/4HANA upgrades. Read it in the browser or download a copy."
                  />
                  <Resume />
                </>
              }
            />
            <Route
              path="contact"
              element={
                <>
                  <Meta
                    title="Contact — freelance SAP Basis support"
                    description="Email, WhatsApp, phone and location for Kashif Raza, SAP Basis consultant in Delhi NCR — available for freelance SAP Basis support and S/4HANA upgrade planning."
                  />
                  <Contact />
                </>
              }
            />
            <Route
              path="*"
              element={
                <>
                  <Meta
                    title="Page not found — Kashif Raza"
                    description="That address does not exist on this site. Head back to the home page, the SAP Library or the portfolio."
                  />
                  <NotFound />
                </>
              }
            />
          </Routes>
        </Suspense>
      </div>
      <Footer />
    </div>
  )
}
